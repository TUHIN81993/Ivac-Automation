const { runAutomation } = require('./ivacAutomation');
runAutomation();
