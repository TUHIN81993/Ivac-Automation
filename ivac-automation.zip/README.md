# IVAC Automation Suite

This Node.js project automates the IVAC appointment and payment system using Puppeteer.

## Features
- CSV-based bulk webfile processing
- CAPTCHA solving using 2Captcha
- Dynamic date/time slot checker
- Manual or automatic OTP entry

## Setup Instructions
1. Install dependencies:
```bash
npm install
```

2. Copy `.env.example` to `.env` and fill in your details.

3. Run automation:
```bash
node index.js
```
